# Input mappings
## Buttons
- btn[0]: system reset
- btn[1]: send pattern generation
- btn[2]: bypass Gaussian blur
## Switches
