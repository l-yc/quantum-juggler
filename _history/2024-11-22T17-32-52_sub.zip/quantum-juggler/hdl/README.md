# Input mappings
## Buttons
- btn[0]: system reset
- btn[1]: send pattern generation
## Switches
- sw[2:0]: next pattern beat
- sw[5:3]: pattern length
- sw[9:6]: lower threshold
- sw[13:10]: upper threshold
- sw[14]: show mask
- sw[15]: show crosshair
